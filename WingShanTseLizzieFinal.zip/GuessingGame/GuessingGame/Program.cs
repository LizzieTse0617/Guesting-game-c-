﻿namespace GuessingGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Test code for RandomInteger
            RandomInteger rn = new (); 
            for( int c = 0; c < 10; c++)
            {
           
                 //   (rn.GenerateRandomNumber());
            }
            RangedRandomInteger rrn = new(1,100);
            for (int c = 0; c < 10; c++)
           {
               
                    //(rrn.GenerateRandomNumber());
            }
                #endregion

                GuestTheNumberGame guessingGame = new();
            guessingGame.Start();

        }
    }
}