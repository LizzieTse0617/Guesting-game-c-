﻿namespace GuessingGame
{
    public class RangedRandomInteger: RandomInteger
    {

        //fields
        protected int minimum = 1; 
        protected int maximum = 10;

        //default constructor
        public RangedRandomInteger()
        {

        }

        //overloaded constructor(take min,max as argument)
        public RangedRandomInteger(int minimum, int maximum)
        {
            this.minimum = minimum;
            this.maximum = maximum;
        }

        //constructor (adding new: means i am intending to override this GenerateRandomNumber method)
        public new int GenerateRandomNumber()
        {
            //adding random here:
            currentRandomNumber = random.Next(minimum, maximum +1); //inclusive/exclusive
            return currentRandomNumber; //TODO fix this!
        }


        //set methods
        public void SetMinimum(int minimum)
        {
            this.minimum = minimum; 
        }

        public void SetMaximum(int maximum)
        {
            this.maximum = maximum;
        }

        //get methods
        public int GetMinimum() { return this.minimum; }
        public int GetMaximum() { return this.maximum; }
    }
}
