﻿
namespace GuessingGame
{
    public class GuestTheNumberGame
    {
        //constants
        private const int MIN_MENU = 0;
        private const int MAX_MENU = 3;


        //fields
        private int guessCount = 0;
        private string input = string.Empty;

      
        private RangedRandomInteger secretNumberGenerator = new(); //composition - "has a relationship"


        //private method
        private int ShowMenu()
        {
            Console.ForegroundColor= ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();

            Console.WriteLine("|____________________________________________________|");
            Console.WriteLine("|                                                    |");
            Console.WriteLine("|  1: Easy                                           |");
            Console.WriteLine("|                                                    |");
            Console.WriteLine("|  2: Normal                                         |");
            Console.WriteLine("|                                                    |");
            Console.WriteLine("|  3: Hard                                           |");
            Console.WriteLine("|                                                    |");
            Console.WriteLine("|  0: Exit                                           |");
            Console.WriteLine("|____________________________________________________|");

  
            // step1 - Let user input a number between 1 and 3
            int level = 0;
            while (level < 1 || level > 3)
            {
                Console.Write("Please enter a number between 1 and 3 to select a level: ");
                string input = Console.ReadLine();
                if (!int.TryParse(input, out level))
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
                else if (level < 1 || level > 3)
                {
                    Console.WriteLine("Invalid input. Please enter a number between 1 and 3.");
                }
              
            }
            //Step2 - start the guessing game with the specified level
            Setup(level);

            return 0; // TODO fix this!
        }

        //after showing Start, it shows menu, now
        private void Setup(int level)
        {
            int minRange = 1;
            int maxRange = 100;

            // Set the range based on the user-selected level
            switch (level)
            {
                case 1:
                    maxRange = 20;
                    break;
                case 2:
                    maxRange = 100;
                    break;
                case 3:
                    maxRange = 1000;
                    break;
            }

            RangedRandomInteger secretNumberGenerator = new RangedRandomInteger(minRange, maxRange);

            Console.WriteLine($"Guess the number between {minRange} and {maxRange}.");

            int secretNumber = secretNumberGenerator.GenerateRandomNumber();

            Play(secretNumber);
        }



        private void Play(int secretNumber)
        {
            bool guessedCorrectly = false;

            while (!guessedCorrectly)
            {
                Console.Write("Enter your guess: ");
                string input = Console.ReadLine();

                int guess;
                bool isValidGuess = int.TryParse(input, out guess);

                if (isValidGuess)
                {
                    guessCount++;

                    if (guess == secretNumber)
                    {
                        Console.WriteLine("Congratulations!");
                        Console.WriteLine($"Total number of guess: {guessCount} .");
                        guessedCorrectly = true;


                    }
                    else if (guess < secretNumber)
                    {
                        Console.WriteLine("Too low!\r\n\r\n ");
                    }
                    else
                    {
                        Console.WriteLine("Too high!\r\n\r\n");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
            }
        }



        //public method
        public GuestTheNumberGame()
        {

        }

        public void Start()
        {
            //calling show menu
            ShowMenu();
        }







    }




}
